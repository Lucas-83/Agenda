package com.example.appt;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv_pacite,tv_nome_consulta,tv_sexo,tv_telefone,tv_endereco,tv_medico,tv_titulo;
    EditText et_nome, et_telefone, et_endereco, et_medico;
    Button btn_gravar, btn_consultar, btn_fechar;
    Switch switchDark;
    Spinner spinner_genero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_main);
        et_nome = findViewById(R.id.et_nome);
        et_telefone = findViewById(R.id.et_telefone);
        et_endereco = findViewById(R.id.et_endereco);
        et_medico = findViewById(R.id.et_medico);
        btn_gravar = findViewById(R.id.btn_gravar);
        btn_consultar = findViewById(R.id.btn_consultar);
        btn_fechar = findViewById(R.id.btn_fechar);
        switchDark = findViewById(R.id.btDark);
        spinner_genero = findViewById(R.id.spinner_genero);
        tv_pacite= findViewById(R.id.tv_paciente);
        tv_nome_consulta = findViewById(R.id.tv_nome_consulta);
        tv_sexo= findViewById(R.id.tv_sexo);
        tv_telefone= findViewById(R.id.tv_telefone);
        tv_endereco= findViewById(R.id.tv_endereco);
        tv_medico= findViewById(R.id.tv_medico);
        tv_titulo= findViewById(R.id.tv_titulo);
        BancoDados.abrirDB(this);
        BancoDados.abrirOuCriarTabela(this);
        BancoDados.fecharDB();

        switchDark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    setDarkTheme();
                } else {
                    setLightTheme();
                }
            }
        });
// Configuração do Spinner
        String[] sexoOptions = {"Masculino", "Feminino"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sexoOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_genero.setAdapter(adapter);
    }

    private void setDarkTheme() {
        // Alterando cores para tema escuro
        getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.black));
        switchDark.setTextColor(getResources().getColor(R.color.dark_text));
        et_nome.setTextColor(getResources().getColor(R.color.dark_text));
        et_telefone.setTextColor(getResources().getColor(R.color.dark_text));
        et_endereco.setTextColor(getResources().getColor(R.color.dark_text));
        et_medico.setTextColor(getResources().getColor(R.color.dark_text));
        btn_consultar.setTextColor(getResources().getColor(R.color.dark_text));
        btn_fechar.setTextColor(getResources().getColor(R.color.dark_text));
        btn_gravar.setTextColor(getResources().getColor(R.color.dark_text));
        tv_pacite.setTextColor(getResources().getColor(R.color.dark_text));
        tv_nome_consulta.setTextColor(getResources().getColor(R.color.dark_text));
        tv_sexo.setTextColor(getResources().getColor(R.color.dark_text));
        tv_telefone.setTextColor(getResources().getColor(R.color.dark_text));
        tv_endereco.setTextColor(getResources().getColor(R.color.dark_text));
        tv_medico.setTextColor(getResources().getColor(R.color.dark_text));
        tv_titulo.setTextColor(getResources().getColor(R.color.dark_text));
        spinner_genero.setPopupBackgroundResource(R.color.dark_text);
        ((TextView) spinner_genero.getSelectedView()).setTextColor(getResources().getColor(R.color.dark_text));

       /*
        // Salvando o estado do tema escuro no SharedPreferences
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("dark_theme_enabled", true);
        editor.apply();

        */
    }

    private void setLightTheme() {
        // Restaurando cores para tema claro
        getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.white));
        switchDark.setTextColor(getResources().getColor(R.color.light_text));
        et_nome.setTextColor(getResources().getColor(R.color.light_text));
        et_telefone.setTextColor(getResources().getColor(R.color.light_text));
        et_endereco.setTextColor(getResources().getColor(R.color.light_text));
        et_medico.setTextColor(getResources().getColor(R.color.light_text));
        btn_consultar.setTextColor(getResources().getColor(R.color.light_text));
        btn_fechar.setTextColor(getResources().getColor(R.color.light_text));
        btn_gravar.setTextColor(getResources().getColor(R.color.light_text));
        tv_pacite.setTextColor(getResources().getColor(R.color.light_text));
        tv_nome_consulta.setTextColor(getResources().getColor(R.color.light_text));
        tv_sexo.setTextColor(getResources().getColor(R.color.light_text));
        tv_telefone.setTextColor(getResources().getColor(R.color.light_text));
        tv_endereco.setTextColor(getResources().getColor(R.color.light_text));
        tv_medico.setTextColor(getResources().getColor(R.color.light_text));
        tv_titulo.setTextColor(getResources().getColor(R.color.light_text));
        spinner_genero.setPopupBackgroundResource(R.color.dark_text);
        ((TextView) spinner_genero.getSelectedView()).setTextColor(getResources().getColor(R.color.light_text));
        /*
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("dark_theme_enabled", false);
        editor.apply();
         */
    }

    public void inserirRegistro(View v) {
        String st_nome, st_fone, genero, medico, endereco;
        st_nome = et_nome.getText().toString().trim();
        st_fone = et_telefone.getText().toString().trim();
        genero = spinner_genero.getSelectedItem().toString();
        medico = et_medico.getText().toString().trim();
        endereco = et_endereco.getText().toString().trim();

        if (st_nome.isEmpty() || st_fone.isEmpty()) {
            CxMsg.mostrar("Campos não podem estar vazios", this);
            return;
        }
        BancoDados.inserirRegistro(st_nome, st_fone, genero, medico, endereco, this);
        et_nome.setText(null);
        et_telefone.setText(null);
        et_medico.setText(null);
        et_endereco.setText(null);
    }

    public void abrir_tela_consulta(View v) {
        Intent it_tela_consulta = new Intent(this, TelaConsulta.class);
        startActivity(it_tela_consulta);
    }

    public void fechar_tela(View v) {
        this.finish();
    }
}
